# Post-processing Stack v1

Need help? Check out the [quick start guide](https://github.com/Unity-Technologies/PostProcessing/wiki) and [the official forums](https://forum.unity3d.com/forums/image-effects.96/).

Found a bug? Let us know and [post an issue](https://github.com/Unity-Technologies/PostProcessing/issues).

Interested in the upcoming Post-processing Stack v2? Check it out in the [v2 branch](https://github.com/Unity-Technologies/PostProcessing/tree/v2)!
